Terminal 1:
```bash
python Server.py 1025
```

Terminal 2:
```bash
python ClientLauncher.py 127.0.0.1 1025 5000 movie.Mjpeg
```
